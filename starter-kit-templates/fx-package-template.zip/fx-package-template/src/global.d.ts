/* eslint-disable no-var */

declare global {
  const __packageName__: string;
  const __buildVersion__: string;
  const __buildDate__: string;
}

export { };
