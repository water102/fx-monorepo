import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { bootstrap } from '@water102/fx-web';

import { AppModule } from './app/app.module';
import { logError } from '@water102/fx-common';

bootstrap(() => {
  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch(logError('bootstrapModule'));
})

import('../package.json')
  .then(packageJson => {
    console.log(`${packageJson.name}: v${packageJson.version}`);
  })
  .catch(logError('loadPackageJson'));