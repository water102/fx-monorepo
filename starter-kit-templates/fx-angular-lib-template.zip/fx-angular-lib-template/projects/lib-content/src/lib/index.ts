/*
 * Public API Surface of # <%= projectName%>
 */

export * from './my-lib.service';
export * from './my-lib.component';
export * from './my-lib.module';