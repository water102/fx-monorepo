import { Component } from '@angular/core';

@Component({
  selector: 'lib-my-lib',
  templateUrl: './my-lib.component.html',
  styles: [
  ]
})
export class MyLibComponent {

}
