import { RouterModule, Routes } from '@angular/router';

import { HandsonTableComponent } from './handson-table.component';
import { NgModule } from '@angular/core';

const routes: Routes = [
  {
    path: '',
    component: HandsonTableComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HandsonTableRoutingModule { }
