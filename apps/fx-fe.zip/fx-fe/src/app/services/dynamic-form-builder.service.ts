// dynamic-form-builder.service.ts
import "reflect-metadata";
import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { getMetadataStorage } from "class-validator";
import { validationMetadatasToSchemas } from 'class-validator-jsonschema'

@Injectable({
  providedIn: 'root',
})
export class DynamicFormBuilderService {
  constructor(private fb: FormBuilder) { }

  buildForm<T extends {}>(model: T): FormGroup {
    const formGroup = this.fb.group({});

    const keys = Object.getOwnPropertyNames(
      // Object.getPrototypeOf(model)
      model
    )

   
    console.log('model', model, keys, Object.keys(model));
    // Get metadata for UserModel properties
function getPropertyMetadata(target: any, propertyName: string): any {
  return Reflect.getMetadata('design:type', target, propertyName);
}

const classType = Object.getPrototypeOf(model)
// Example usage
const nameType = getPropertyMetadata(classType, 'name');
const emailType = getPropertyMetadata(classType, 'email');
const ageType = getPropertyMetadata(classType, 'age');

console.log('Name Property Type:', nameType);
console.log('Email Property Type:', emailType);
console.log('Age Property Type:', ageType, ageType());

const schemas = validationMetadatasToSchemas(classType)
console.log(JSON.stringify(schemas))


    // let result = Reflect.getOwnMetadataKeys(target, propertyKey);

    // const validationMetadata = getValidationMetadata(modelClass);

    // for (const property of validationMetadata) {
    //   const propertyName = property.propertyName as string;
    //   const constraints = property.constraints as Record<string, any>;

    //   const validators = this.getValidators(constraints);

    //   // formGroup.addControl(propertyName, this.fb.control('', validators));
    // }

    return formGroup;
  }

  private getValidators(constraints: Record<string, any>): Validators[] {
    const validators: Validators[] = [];

    if (constraints.required) {
      validators.push(Validators.required);
    }

    if (constraints.isEmail) {
      validators.push(Validators.email);
    }

    // Add more custom validation rules based on constraints

    return validators;
  }
}
