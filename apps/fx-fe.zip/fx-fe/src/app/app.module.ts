import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FxAngularModule } from '@water102/fx-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'

import { NgFor, AsyncPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HomepageComponent } from './views/homepage/homepage.component';
import { DynamicFormBuilderService } from './services';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FxAngularModule,
    BrowserAnimationsModule,

    //
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    NgFor,
    AsyncPipe,
  ],
  providers: [
    DynamicFormBuilderService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
