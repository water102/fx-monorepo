import { Component, OnInit, VERSION } from '@angular/core';
import { FormControl } from '@angular/forms';
import { randomIntBetween } from '@water102/fx-common'
import { Observable, map, startWith } from 'rxjs';
import { DynamicFormBuilderService } from './services';
import { UserModel } from './models';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  versionName = 'Angular ' + VERSION.major;
  no = randomIntBetween(0, 100);
  welcome = 'Welcome to';

  myControl = new FormControl('');
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]> | undefined;

  constructor(
    private dynamicFormBuilderService: DynamicFormBuilderService
  ) {
    const model = new UserModel()
    model.age = 100
    this.dynamicFormBuilderService.buildForm(model)
  }

  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );

    const observable$ = new Observable<string>(subscriber => {
      console.log('observable executed');
      subscriber.next('Bean')
      setTimeout(() => {
        subscriber.next('Bob')
      }, 2000);
      setTimeout(() => {
        subscriber.next('Ben')
      }, 4000);
    })

    const subscription1 = observable$.subscribe((value: unknown) => console.log('Subscription 1', value));

    setTimeout(() => {
      const subscription2 = observable$.subscribe((value: unknown) => console.log('Subscription 2', value));
    }, 1000);
    // setTimeout(() => {
    //   console.log('Unsubscribe');
    //   subscription.unsubscribe()
    // }, 3000);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }
}