import { Component } from '@angular/core';

@Component({
  selector: 'handson-table',
  templateUrl: './handson-table.component.html',
})
export class HandsonTableComponent { 
}