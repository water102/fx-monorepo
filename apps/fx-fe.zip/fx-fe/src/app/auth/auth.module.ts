import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HandsonTableComponent } from './login.component';
import { HandsonTableRoutingModule } from './auth-routing.module';

import { HotTableModule } from '@handsontable/angular';
import { registerAllModules } from 'handsontable/registry';

// register Handsontable's modules
registerAllModules();

@NgModule({
  imports: [
    CommonModule,
    HandsonTableRoutingModule,
    HotTableModule
  ],
  declarations: [HandsonTableComponent]
})
export class HandsontableModule { }

