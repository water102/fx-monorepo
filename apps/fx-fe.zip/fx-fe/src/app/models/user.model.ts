// user.model.ts
import { IsDefined, IsEmail, IsInt, Min, Max } from 'class-validator';

export class UserModel {
  @IsDefined()
  name: string = '';

  @IsEmail()
  email: string = '';

  @IsInt()
  @Min(0)
  @Max(150)
  age: number = 0;
}
