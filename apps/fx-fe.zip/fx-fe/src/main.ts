import './polyfills'

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { bootstrap } from '@water102/fx-web';

import { AppModule } from './app/app.module';
import { enableProdMode } from '@angular/core';
import { environment } from './environments';

bootstrap(window, document)(() => {
  console.log('env',  import.meta.env.NG_APP_API_BASE_URL);
  if (environment.production) {
    enableProdMode();
  }

  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch((err: unknown) => console.error(err));
})

import('../package.json')
  .then(packageJson => {
    console.log(`${packageJson.name}: v${packageJson.version}`);
  })
  .catch((err: unknown) => console.error(err));